package com.gem.bbs.mapper;


import com.gem.bbs.entity.Likes;

public interface LikesMapper {
    void insert (Likes likes);
}
