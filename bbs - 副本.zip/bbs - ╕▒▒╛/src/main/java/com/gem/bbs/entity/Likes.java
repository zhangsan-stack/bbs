package com.gem.bbs.entity;

import lombok.Data;

@Data
public class Likes {
    private  Integer id;
    private  Integer  answerid;
    private  Integer userid;


}
