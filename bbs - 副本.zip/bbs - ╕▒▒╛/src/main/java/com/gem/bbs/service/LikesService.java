package com.gem.bbs.service;

import com.gem.bbs.entity.Likes;

public interface LikesService {
    void insert(Likes likes);
}
