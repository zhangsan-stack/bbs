package com.select.mapper;

import com.select.entity.Admin;

public interface AdminMapper {
    Admin selectById(Integer id);

}
