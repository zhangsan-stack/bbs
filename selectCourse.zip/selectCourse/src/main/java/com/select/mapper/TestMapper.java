package com.select.mapper;

import com.select.entity.Test;

public interface TestMapper {
    void  insert(Test test);
}
