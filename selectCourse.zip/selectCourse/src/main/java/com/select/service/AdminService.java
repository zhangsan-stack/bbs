package com.select.service;

import com.select.entity.Admin;

public interface AdminService {
    Admin selectById(Integer id);


}
