package com.select.service;

import com.select.entity.Test;

public interface TestService {
    void insert (Test test);
}
