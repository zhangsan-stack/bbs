package com.select.entity;

import lombok.Data;

@Data
public class Test {
    private Integer id;
    private String  username ;
    private String  password;
}
